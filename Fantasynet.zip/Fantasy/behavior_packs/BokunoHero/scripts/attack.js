import * as mc from "@minecraft/server";
import * as general from "./modules/general.js";

mc.world.afterEvents.entityHurt.subscribe((event) => {
  const
    Apanhador = event.hurtEntity,
    Batedor = event.damageSource.damagingEntity;
  Apanhador.runCommandAsync(`summon wesl3y:health ~~1~ ~ ~ minecraft:entity_spawned §c-${Math.round(event.damage)}`);
  if (Apanhador === undefined || Batedor === undefined) return;
  if (Batedor.hasTag(`stun`)) {
    Apanhador.runCommandAsync("tp @s ~~~");
  }
  if (Batedor.typeId !== "minecraft:player") return;
  const
    inventory = Batedor.getComponent("inventory"),
    container = inventory.container,
    hand = container.getItem(Batedor.selectedSlot);
  if (Batedor.typeId == "minecraft:player" && general.getScore('stamina', Batedor) > 150 && hand && hand.typeId == "wesl3y:quirk_all_for_one") all_for_one(Batedor, Apanhador);
  if (Batedor.typeId == "minecraft:player" && general.getScore('stamina', Batedor) > 150 && hand && hand.typeId == "wesl3y:quirk_copy") copy(Batedor, Apanhador);
});

function all_for_one(Batedor, Apanhador) {
  if (Apanhador.hasTag(`quirk_all_for_one`) || Apanhador.hasTag(`quirk_all_for_one2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_all_for_one,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_all_for_one,quantity=!1..}] wesl3y:quirk_all_for_one`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_all_for_one,quantity=1..}] wesl3y:quirk_all_for_one`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_all_for_one2`);
  }
  if (Apanhador.hasTag(`quirk_black_whip`) || Apanhador.hasTag(`quirk_black_whip2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_black_whip,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_black_whip,quantity=!1..}] wesl3y:quirk_black_whip`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_black_whip,quantity=1..}] wesl3y:quirk_black_whip`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_black_whip2`);
  }
  if (Apanhador.hasTag(`quirk_copy`) || Apanhador.hasTag(`quirk_copy2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_copy,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_copy,quantity=1..}] wesl3y:quirk_copy`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_copy2`);
  }
  if (Apanhador.hasTag(`quirk_cremation`) || Apanhador.hasTag(`quirk_cremation2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_cremation,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_cremation,quantity=!1..}] wesl3y:quirk_cremation`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_cremation,quantity=1..}] wesl3y:quirk_cremation`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_cremation2`);
  }
  if (Apanhador.hasTag(`quirk_dark_shadow`) || Apanhador.hasTag(`quirk_dark_shadow2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_dark_shadow,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_dark_shadow,quantity=!1..}] wesl3y:quirk_dark_shadow`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_dark_shadow,quantity=1..}] wesl3y:quirk_dark_shadow`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_dark_shadow2`);
  }
  if (Apanhador.hasTag(`quirk_decay`) || Apanhador.hasTag(`quirk_decay2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_decay,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_decay,quantity=!1..}] wesl3y:quirk_decay`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_decay,quantity=1..}] wesl3y:quirk_decay`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_decay2`);
  }
  if (Apanhador.hasTag(`quirk_danger_sensor`) || Apanhador.hasTag(`quirk_danger_sensor2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_danger_sensor,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_danger_sensor,quantity=!1..}] wesl3y:quirk_danger_sensor`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_danger_sensor,quantity=1..}] wesl3y:quirk_danger_sensor`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_danger_sensor2`);
  }
  if (Apanhador.hasTag(`quirk_electrification`) || Apanhador.hasTag(`quirk_electrification2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_electrification,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_electrification,quantity=!1..}] wesl3y:quirk_electrification`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_electrification,quantity=1..}] wesl3y:quirk_electrification`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_electrification2`);
  }
  if (Apanhador.hasTag(`quirk_explosion`) || Apanhador.hasTag(`quirk_explosion2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_explosion,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_explosion,quantity=!1..}] wesl3y:quirk_explosion`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_explosion,quantity=1..}] wesl3y:quirk_explosion`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_explosion2`);
  }
  if (Apanhador.hasTag(`quirk_fierce_wings`) || Apanhador.hasTag(`quirk_fierce_wings2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_fierce_wings,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_fierce_wings,quantity=!1..}] wesl3y:quirk_fierce_wings`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_fierce_wings,quantity=1..}] wesl3y:quirk_fierce_wings`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_fierce_wings2`);
  }
  if (Apanhador.hasTag(`quirk_float`) || Apanhador.hasTag(`quirk_float2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_float,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_float,quantity=!1..}] wesl3y:quirk_float`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_float,quantity=1..}] wesl3y:quirk_float`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_float2`);
  }
  if (Apanhador.hasTag(`quirk_halfcold_halfhot`) || Apanhador.hasTag(`quirk_halfcold_halfhot2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_halfcold_halfhot,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_halfcold_halfhot,quantity=!1..}] wesl3y:quirk_halfcold_halfhot`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_halfcold_halfhot,quantity=1..}] wesl3y:quirk_halfcold_halfhot`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_halfcold_halfhot2`);
  }
  if (Apanhador.hasTag(`quirk_hell_flame`) || Apanhador.hasTag(`quirk_hell_flame2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_hell_flame,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_hell_flame,quantity=!1..}] wesl3y:quirk_hell_flame`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_hell_flame,quantity=1..}] wesl3y:quirk_hell_flame`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_hell_flame2`);
  }
  if (Apanhador.hasTag(`quirk_ice`) || Apanhador.hasTag(`quirk_ice2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_ice,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_ice,quantity=!1..}] wesl3y:quirk_ice`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_ice,quantity=1..}] wesl3y:quirk_ice`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_ice2`);
  }
  if (Apanhador.hasTag(`quirk_one_for_all`) || Apanhador.hasTag(`quirk_one_for_all2`)) {
    if (getScore("level", Batedor) > 90 && general.getScore("body_strength", Batedor) > 19) {
      Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_one_for_all,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
      Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_one_for_all,quantity=!1..}] wesl3y:quirk_one_for_all`);
      Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_all_for_one,quantity=1..}] wesl3y:quirk_one_for_all`);
      Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_one_for_all2`);
    } else Batedor.runCommandAsync(`tellraw @s {\"rawtext\":[{\"text\":\"§c\"},{\"translate\":\"all_for_one.ofa\"}]}`);
  }
  if (Apanhador.hasTag(`quirk_overhaul`) || Apanhador.hasTag(`quirk_overhaul2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_overhaul,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_overhaul,quantity=!1..}] wesl3y:quirk_overhaul`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_overhaul,quantity=1..}] wesl3y:quirk_overhaul`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_overhaul2`);
  }
  if (Apanhador.hasTag(`quirk_rabbit`) || Apanhador.hasTag(`quirk_rabbit2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_rabbit,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_rabbit,quantity=!1..}] wesl3y:quirk_rabbit`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_rabbit,quantity=1..}] wesl3y:quirk_rabbit`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_rabbit2`);
  }
  if (Apanhador.hasTag(`quirk_regeneration`) || Apanhador.hasTag(`quirk_regeneration2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_regeneration,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_regeneration,quantity=!1..}] wesl3y:quirk_regeneration`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_regeneration,quantity=1..}] wesl3y:quirk_regeneration`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_regeneration2`);
  }
  if (Apanhador.hasTag(`quirk_size`) || Apanhador.hasTag(`quirk_size2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_size,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_size,quantity=!1..}] wesl3y:quirk_size`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_size,quantity=1..}] wesl3y:quirk_size`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_size2`);
  }
  if (Apanhador.hasTag(`quirk_smoke_screen`) || Apanhador.hasTag(`quirk_smoke_screen2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_smoke_screen,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_smoke_screen,quantity=!1..}] wesl3y:quirk_smoke_screen`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_smoke_screen,quantity=1..}] wesl3y:quirk_smoke_screen`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_smoke_screen2`);
  }
  if (Apanhador.hasTag(`quirk_stress`) || Apanhador.hasTag(`quirk_stress2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_stress,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_stress,quantity=!1..}] wesl3y:quirk_stress`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_stress,quantity=1..}] wesl3y:quirk_stress`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_stress2`);
  }
  if (Apanhador.hasTag(`quirk_zero_gravity`) || Apanhador.hasTag(`quirk_zero_gravity2`)) {
    Batedor.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:quirk_zero_gravity,quantity=!1..}] {"rawtext":[{"translate":"all_for_one.copy"}]}`);
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_zero_gravity,quantity=!1..}] wesl3y:quirk_zero_gravity`);
    Apanhador.runCommandAsync(`clear @s[type=player,hasitem={item=wesl3y:quirk_zero_gravity,quantity=1..}] wesl3y:quirk_zero_gravity`);
    Apanhador.runCommandAsync(`tag @s[type=!player] remove quirk_zero_gravity2`);
  }
}







function copy(Batedor, Apanhador) {
  if (Apanhador.hasTag(`quirk_all_for_one`) || Apanhador.hasTag(`quirk_all_for_one2`)) {
    Batedor.runCommandAsync(`tellraw @s {\"rawtext\":[{\"text\":\"§c\"},{\"translate\":\"copy.no_copy\"}]}`);
  }
  if (Apanhador.hasTag(`quirk_black_whip`) || Apanhador.hasTag(`quirk_black_whip`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_black_whip,quantity=!1..}] wesl3y:quirk_black_whip`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_black_whip,quantity=1..}] wesl3y:quirk_copy`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_black_whip,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_cremation`) || Apanhador.hasTag(`quirk_cremation2`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_cremation,quantity=!1..}] wesl3y:quirk_cremation`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_cremation,quantity=1..}] wesl3y:quirk_copy`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_cremation,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_dark_shadow`) || Apanhador.hasTag(`quirk_dark_shadow2`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_dark_shadow,quantity=!1..}] wesl3y:quirk_dark_shadow`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_dark_shadow,quantity=1..}] wesl3y:quirk_copy`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_dark_shadow,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_decay`) || Apanhador.hasTag(`quirk_decay2`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_decay,quantity=!1..}] wesl3y:quirk_decay`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_decay,quantity=1..}] wesl3y:quirk_copy`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_decay,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_danger_sensor`) || Apanhador.hasTag(`quirk_danger_sensor2`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_danger_sensor,quantity=!1..}] wesl3y:quirk_danger_sensor`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_danger_sensor,quantity=1..}] wesl3y:quirk_copy`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_danger_sensor,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_electrification`) || Apanhador.hasTag(`quirk_electrification2`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_electrification,quantity=!1..}] wesl3y:quirk_electrification 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_electrification,quantity=1..}] wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_electrification,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_explosion`) || Apanhador.hasTag(`quirk_explosion2`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_explosion,quantity=!1..}] wesl3y:quirk_explosion 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_explosion,quantity=1..}] wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_explosion,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_fierce_wings`) || Apanhador.hasTag(`quirk_fierce_wings2`)) {
    Batedor.runCommandAsync(`tellraw @s {\"rawtext\":[{\"text\":\"§c\"},{\"translate\":\"copy.no_copy\"},{\"text\":\"\nQuirk Transformation\"}]}`);
  }
  if (Apanhador.hasTag(`quirk_float`) || Apanhador.hasTag(`quirk_float2`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_float,quantity=!1..}] wesl3y:quirk_float`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_float,quantity=1..}] wesl3y:quirk_copy`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_float,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_halfcold_halfhot`) || Apanhador.hasTag(`quirk_halfcold_halfhot2`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_halfcold_halfhot,quantity=!1..}] wesl3y:quirk_explosion 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_halfcold_halfhot,quantity=1..}] wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_halfcold_halfhot,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_hell_flame`) || Apanhador.hasTag(`quirk_hell_flame2`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_hell_flame,quantity=!1..}] wesl3y:quirk_hell_flame`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_hell_flame,quantity=1..}] wesl3y:quirk_copy`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_hell_flame,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_ice`) || Apanhador.hasTag(`quirk_ice2`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_ice,quantity=!1..}] wesl3y:quirk_ice`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_ice,quantity=1..}] wesl3y:quirk_copy`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_ice,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_one_for_all`) || Apanhador.hasTag(`quirk_one_for_all2`)) {
    Batedor.runCommandAsync(`tellraw @s {\"rawtext\":[{\"text\":\"§c\"},{\"translate\":\"copy.no_copy\"}]}`);
  }
  if (Apanhador.hasTag(`quirk_overhaul`) || Apanhador.hasTag(`quirk_overhaul2`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_overhaul,quantity=!1..}] wesl3y:quirk_overhaul`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_overhaul,quantity=1..}] wesl3y:quirk_copy`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_overhaul,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_rabbit`) || Apanhador.hasTag(`quirk_rabbit2`)) {
    Batedor.runCommandAsync(`tellraw @s {\"rawtext\":[{\"text\":\"§c\"},{\"translate\":\"copy.no_copy\"},{\"text\":\"\nQuirk Transformation\"}]}`);
  }
  if (Apanhador.hasTag(`quirk_regeneration`) || Apanhador.hasTag(`quirk_regeneration`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_regeneration,quantity=!1..}] wesl3y:quirk_regeneration 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_regeneration,quantity=1..}] wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_regeneration,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_size`) || Apanhador.hasTag(`quirk_size2`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_size,quantity=!1..}] wesl3y:quirk_size`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_size,quantity=1..}] wesl3y:quirk_copy`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_size,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_smoke_screen`) || Apanhador.hasTag(`quirk_smoke_screen2`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_smoke_screen,quantity=!1..}] wesl3y:quirk_smoke_screen 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_smoke_screen,quantity=1..}] wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_smoke_screen,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_stress`) || Apanhador.hasTag(`quirk_stress2`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_stress,quantity=!1..}] wesl3y:quirk_stress 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_stress,quantity=1..}] wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_stress,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
  if (Apanhador.hasTag(`quirk_zero_gravity`) || Apanhador.hasTag(`quirk_zero_gravity2`)) {
    Batedor.runCommandAsync(`give @s[hasitem={item=wesl3y:quirk_zero_gravity,quantity=!1..}] wesl3y:quirk_zero_gravity 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    Batedor.runCommandAsync(`clear @s[hasitem={item=wesl3y:quirk_zero_gravity,quantity=1..}] wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    Batedor.runCommandAsync(`replaceitem entity @s[hasitem={item=wesl3y:quirk_zero_gravity,quantity=1..}] slot.armor.head 0 wesl3y:quirk_copy 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
  }
}