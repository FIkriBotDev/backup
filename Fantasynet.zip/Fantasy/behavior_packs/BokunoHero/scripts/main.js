import './attack.js';
import './menu.js';
import './quests.js';
import './titles.js';