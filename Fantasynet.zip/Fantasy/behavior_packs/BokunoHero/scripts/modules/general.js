import * as mc from "@minecraft/server";

export function getScore(objective, player) { try { return mc.world.scoreboard.getObjective(objective).getScore(player.scoreboardIdentity); } catch (error) { return 0; } }

export const clamp = (num, min, max = 1e9) => Math.min(Math.max(num, min), max), setTimer = (callback, value = 1) => mc.system.run(data => mc.system.currentTick % (20 * value) === 0 ? callback() : false), overworld = mc.world.getDimension("overworld"), nether = mc.world.getDimension("nether"), theEnd = mc.world.getDimension("the end");