<?php 
   $ip = "play-fantasynetwork.ddns.net";
   $port = 19132;
?> 