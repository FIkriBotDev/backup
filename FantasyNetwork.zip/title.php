<?php 
$title = "FantasyNetwork"; ?>