<?php 
//tempat menyimpan variabel image slide

    $slide1img = "assets/img/slide/slide-s3.png";
    $slide2img = "assets/img/slide/slide1.jpg";
    $slide3img = "assets/img/slide/slide-1.jpg";

?>