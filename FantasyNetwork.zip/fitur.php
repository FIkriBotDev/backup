<?php 
$fitur1 = "s";
$fitur2 = "";
$fitur3 = "";
$fitur4 = "";
$fitur5 = "";
$fitur6 = "";
$fitur7 = "";
$fitur8 = "";
$fitur9 = "";

?>