<?php 
include "title.php";
include "ipport.php";
$headbtn = "Home"; //home button
    $headbtnclick = "#";

              $headbtnbtn = "GRUP WA"; //tombol menuju whatsapp grup
              $headbtnbtnclick = "https://chat.whatsapp.com/JmI4iXdPcEsAhKmKGMU5jf"; 

            $btnplay = "Main Sekarang!"; //tombol play
            $btnplayclick = "minecraft://?addExternalServer=$title|$ip:$port";
            
        $aboutbtn = "Baca Selengkapnya"; //tombol about
        $aboutbtnclick = "#about";
              ?>