<?php 
    //team 1 variable
    $team1 = "Owner";
    $team1name = "Teddy";
    $team1slogan = "Kalau orang lain bisa kenapa harus saya, kalau orang lain tidak bisa... apalagi saya";
    $team1wa = "https://wa.me/6285717693675";

    //team 2 variable
    $team2 = "Web Developer";
    $team2name = "F1KR7/Kacunh1945";
    $team2slogan = "Kegagalan adalah berhasil menjadi orang gagal";
    $team2wa = "https://wa.me/6287769811262";

    //team 3 variable
    $team3 = "Commander";
    $team3name = "DinoVshop";
    $team3slogan = "Kunci kesehatan cuma satu, yaitu jangan sakit.";
    $team3wa = "https://wa.me/6285337579419";

    //team 4 variable
    $team4 = "Admin";
    $team4name = "Zidan";
    $team4slogan = "Ketika kamu malas, bukan berarti kamu rajin.";
    $team4wa = "https://wa.me/6281325353036";

?>
<section id='team' class='team section-bg'>
      <div class='container'>

        <div class='section-title'>
          <h2>Team</h2>
          <p>Our Team</p>
        </div>

        <div class='row'>
<?php include "title.php"; ?>
          <div class='col-lg-6'>
            <div class='member d-flex align-items-start'>
              <div class='pic'><img src='assets/img/team/team.png' class='img-fluid' alt=''></div>
              <div class='member-info'>
                <h4><?=$team1name?></h4>
                <span><?=$team1?> <?=$title?></span>
                <p><?=$team1slogan?></p>
                <div class='social'>
                  <a href='<?=$team1wa?>'><i class='ri-whatsapp-fill'></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class='col-lg-6 mt-4 mt-lg-0'>
            <div class='member d-flex align-items-start'>
              <div class='pic'><img src='assets/img/team/team.png' class='img-fluid' alt=''></div>
              <div class='member-info'>
                <h4><?=$team2name?></h4>
                <span><?=$team2?></span>
                <p><?=$team2slogan?></p>
                <div class='social'>
                  <a href='<?=$team2wa?>'><i class='ri-whatsapp-fill'></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class='col-lg-6 mt-4'>
            <div class='member d-flex align-items-start'>
              <div class='pic'><img src='assets/img/team/team.png' class='img-fluid' alt=''></div>
              <div class='member-info'>
                <h4><?=$team3name?></h4>
                <span><?=$team3?></span>
                <p><?=$team3slogan?></p>
                <div class='social'>
                  <a href='<?=$team3wa?>'><i class='ri-whatsapp-fill'></i></a>
                  </div>
              </div>
            </div>
          </div>

          <div class='col-lg-6 mt-4'>
            <div class='member d-flex align-items-start'>
              <div class='pic'><img src='assets/img/team/team.png' class='img-fluid' alt=''></div>
              <div class='member-info'>
                <h4><?=$team4name?></h4>
                <span><?=$team4?></span>
                <p><?=$team4slogan?></p>
                <div class='social'>
                  <a href='<?=$team4wa?>'><i class='ri-whatsapp-fill'></i></a>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>