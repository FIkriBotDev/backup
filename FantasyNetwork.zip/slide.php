<?php include "slide-background.php"; ?>
<div class='carousel-item active' style='background-image: url(<?=$slide1img?>)'>
          <div class='carousel-container'>
            <div class='container'>
              <h2 class='animate__animated animate__fadeInDown'>Welcome to <span><?=$title?></span></h2>
              <p class='animate__animated animate__fadeInUp'><?=$ip?> | <?=$port?></p>
              <a href='<?=$btnplayclick?>'><button class='btn btn-primary'><?=$btnplay?></button></a>
            </div>
          </div>
        </div>
                        <?php include "button.php"; ?>
        <!-- Slide 2 -->
        <div class='carousel-item' style='background-image: url(<?=$slide2img?>)'>
          <div class='carousel-container'>
            <div class='container'>
              <h2 class='animate__animated animate__fadeInDown'>Apa itu <span><?=$title?>?</span></h2>
              <p class='animate__animated animate__fadeInUp'><?=$title?> adalah sebuah server minecraft bedrock edition yang berasal dari Indonesia, dengan mod Fantasy.</p>
              <a href='<?=$aboutbtnclick?>' class='btn-get-started animate__animated animate__fadeInUp scrollto'><?=$aboutbtn?></a>
            </div>
          </div>
        </div>

        <!-- Slide 3 -->
        <div class='carousel-item' style='background-image: url(<?=$slide3img?>)'>
          <div class='carousel-container'>
            <div class='container'>
              <h2 class='animate__animated animate__fadeInDown'>Fiturnya apa aja?</h2>
              <p class='animate__animated animate__fadeInUp'>Fiturnya adalah server ini akan memakai addon berbeda dan menarik di setiap season</p>
              <a href='<?=$aboutbtnclick?>' class='btn-get-started animate__animated animate__fadeInUp scrollto'><?=$aboutbtn?></a>
            </div>
          </div>
        </div>

      </div>

      <a class='carousel-control-prev' href='#heroCarousel' role='button' data-bs-slide='prev'>
        <span class='carousel-control-prev-icon bi bi-chevron-left' aria-hidden='true'></span>
      </a>

      <a class='carousel-control-next' href='#heroCarousel' role='button' data-bs-slide='next'>
        <span class='carousel-control-next-icon bi bi-chevron-right' aria-hidden='true'></span>
      </a>

    </div>
  </section>