<!-- ======= Header ======= -->
<header id='header' class='fixed-top d-flex align-items-center'>
    <div class='container d-flex align-items-center'>

      <h1 class='logo me-auto' id='myHeading'></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href='index.html' class='logo me-auto'><img src='assets/img/logo.png' alt='' class='img-fluid'></a>-->

      <nav id='navbar' class='navbar'>
        <ul>
          <?php 
                include "button.php";
          ?>
          <li><a href='<?=$headbtnclick?>' class='active'><?=$headbtn?></a></li>

          <li><a href='<?=$headbtnbtnclick?>' class='getstarted'><?=$headbtnbtn?></a></li>
        </ul>
        <i class='bi bi-list mobile-nav-toggle'></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->