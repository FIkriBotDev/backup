<?php 
    $status = 3;
switch($status)
{
    case 1 : $stat = "Online";
    break;
    case 2 : $stat = "Offline";
    break;
    case 3 : $stat = "Perbaikan";
    break;
    case 4 : $stat = "Proses";
    break;
}
//kamu bisa mengubah status dengan nomor yang telah ada
?>