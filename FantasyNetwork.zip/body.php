<body>
    <?php include "navbar.php";
            include "title.php";
              include "status.php";
      ?>
  <header id='header' class='fixed-top d-flex align-items-center'>
    <div class='container d-flex align-items-center'>
    <h1 class="logo me-auto" ><?=$title?> - <?=$stat?></h1>

      <nav id='navbar' class='navbar'>
        <ul>
        <?php 
                include "button.php";
          ?>
          <li><a href='<?=$headbtnclick?>' class='active'><?=$headbtn?></a></li>

          <li><a href='<?=$headbtnbtnclick?>' class='getstarted'><?=$headbtnbtn?></a></li>
        </ul>
        <i class='bi bi-list mobile-nav-toggle'></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id='hero'>
    <div id='heroCarousel' data-bs-interval='5000' class='carousel slide carousel-fade' data-bs-ride='carousel'>

      
      <div class='carousel-inner' role='listbox'>
<?php include "button.php"; 
      include "ipport.php";
      ?>
        <!-- Slide -->
        <?php include "slide.php"; ?>
        <!-- End Slide -->

  <main id='main'>

    <!-- ======= About Section ======= -->
    <section id='about' class='about'>
      <div class='container'>

        <div class='row content'>
          <div class='col-lg-6'>
            <h2>FantasyNet</h2>
            <h3><?=$title?> adalah server minecraft bedrock edition yang berasal dari Indonesia, dengan mod fantasy.</h3>
          </div>
          <div class='col-lg-6 pt-4 pt-lg-0'>
            <p>
              Ayo bergabung ke <?=$title?>, nyesel ga join:).. Ini fiturnya:
            </p>
            <ul> <?php include "fitur.php"; ?>
              <li><i class='ri-check-double-line'></i> <?=$fitur1;?></li>
              <li><i class='ri-check-double-line'></i> <?=$fitur2;?></li>
              <li><i class='ri-check-double-line'></i> <?=$fitur3;?></li>
              <li><i class='ri-check-double-line'></i> <?=$fitur4;?></li>
              <li><i class='ri-check-double-line'></i> <?=$fitur5;?></li>
              <li><i class='ri-check-double-line'></i> <?=$fitur6;?></li>
              <li><i class='ri-check-double-line'></i> <?=$fitur7;?></li>
              <li><i class='ri-check-double-line'></i> <?=$fitur8;?></li>
              <li><i class='ri-check-double-line'></i> <?=$fitur9;?></li>
            </ul>
            <p class='fst-italic'>
              Dan terimakasih telah bergabung:) Semoga betah...
            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    
    <!-- ======= Services Section ======= -->
    <?php include "team.php"; ?>
    <!-- End Services Section -->
    
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id='footer'>
    <div class='footer-top'>
      <div class='container'>
        <div class='row'>

          <div class='col-lg-3 col-md-6'>
            <div class='footer-info'>
              <h3><?=$title?></h3>
              
          
          <div class='col-lg-4 col-md-6 footer-newsletter'>
            <form action='' method='post'>
              <input type='email' name='email'><input type='submit' value='Subscribe'>
            </form>

          </div>

        </div>
      </div>
    </div>

    <div class='container'>
      <div class='copyright'>
        © Copyright <strong><span><?=$title?></span></strong>. All Rights Reserved
      </div>
      <div class='credits'>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href='#' class='back-to-top d-flex align-items-center justify-content-center'><i class='bi bi-arrow-up-short'></i></a>

  <!-- Vendor JS Files -->
  <script src='assets/vendor/bootstrap/js/bootstrap.bundle.min.js'></script>
  <script src='assets/vendor/glightbox/js/glightbox.min.js'></script>
  <script src='assets/vendor/isotope-layout/isotope.pkgd.min.js'></script>
  <script src='assets/vendor/swiper/swiper-bundle.min.js'></script>
  <script src='assets/vendor/waypoints/noframework.waypoints.js'></script>
  <script src='assets/vendor/php-email-form/validate.js'></script>

  <!-- Template Main JS File -->
  <script src='assets/js/main.js'></script>
  <script>
    const date = new Date();
const angkaBln = date.getMonth() + 1;
const year = date.getFullYear().toString().substr(-2);
const day = date.getDate();
const caseSeason = date.getMonth() + 1;

let namaBln;
switch (angkaBln) {
  case 1:
    namaBln = "Januari";
    break;
  case 2:
    namaBln = "Februari";
    break;
  case 3:
    namaBln = "Maret";
    break;
  case 4:
    namaBln = "April";
    break;
  case 5:
    namaBln = "Mei";
    break;
  case 6:
    namaBln = "Juni";
    break;
  case 7:
    namaBln = "Juli";
    break;
  case 8:
    namaBln = "Agustus";
    break;
  case 9:
    namaBln = "September";
    break;
  case 10:
    namaBln = "Oktober";
    break;
  case 11:
    namaBln = "November";
    break;
  case 12:
    namaBln = "Desember";
    break;
}

let season;
switch (caseSeason) {
  case 1:
    season = "S3";
    break;
  case 2:
    season = "S4";
    break;
  case 3:
    season = "S5";
    break;
  case 4:
    season = "S6";
    break;
  case 5:
    season = "S7";
    break;
  case 6:
    season = "S8";
    break;
  case 7:
    season = "S9";
    break;
  case 8:
    season = "S10";
    break;
  case 9:
    season = "S11";
    break;
  case 10:
    season = "S12";
    break;
  case 11:
    season = "S13";
    break;
  case 12:
    season = "S14";
    break;
}

const myHeading = document.getElementById("myHeading");
myHeading.textContent = `<?=$title?> - ${day} ${namaBln} 20${year}`;
  </script>



</body>