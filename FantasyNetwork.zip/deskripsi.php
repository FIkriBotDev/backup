<?php
$deskripsi = "Sebuah server minecraft bedrock indonesia dengan mod Fantasy.";
?>